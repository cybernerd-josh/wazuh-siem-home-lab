# 👹 SendMonster

**Interactive colourful SMTP campaign tool for Linux**

SendMonster lets you manage an SMTP pool with rotation, import email & phone leads, edit HTML campaign letters (with QR codes & attachments), and convert phone numbers that support email-to-SMS gateways into email addresses for campaigns.

> ⚠️ **Important (2026)**: Most major US carrier free email-to-SMS gateways (AT&T, T-Mobile, and soon Verizon) have been shut down or heavily filtered. The SMTP2SMS feature includes historical + remaining mappings and will warn you. For reliable bulk SMS use a proper A2P / 10DLC provider.

## Features

- **SMTP Pool** – Add multiple SMTP accounts, test them, rotate round-robin or random while sending
- **Leads** – Manage email lists and phone lists (import from TXT/CSV)
- **SMTP2SMS** – Detect / select carrier, convert supporting numbers to `number@gateway` format
- **Campaign Editor** – HTML templates with placeholders (`{{name}}`, `{{email}}`…), QR code generation, file attachments
- **Sending** – Progress bars, rate limiting per SMTP, logging, dry-run mode
- **Colourful TUI** – Powered by Rich (panels, tables, progress, banners)

## Requirements

- Python 3.10+
- Linux (or any Unix-like with a colour terminal)

```bash
pip install -r requirements.txt
```

## Quick Start

```bash
cd sendmonster
python sendmonster.py
```

Data is stored in `./data/` (smtps.json, leads, campaigns, etc.).

## Menu Overview

1. **SMTP Pool Manager** – add / list / test / remove / set rotation mode
2. **Lead Manager** – email leads & phone leads
3. **SMTP2SMS Converter** – phones → carrier check → email gateway addresses
4. **Campaign Editor** – create/edit HTML, add QR, attachments
5. **Send Campaign** – pick list + template + SMTP pool → fire
6. **Settings / About**

## Legal & Ethics

Only send to people who have opted in. Comply with CAN-SPAM, TCPA, GDPR, and your local laws. Abuse of SMTP or SMS gateways can get accounts banned and may be illegal.

## License

MIT – use responsibly.
