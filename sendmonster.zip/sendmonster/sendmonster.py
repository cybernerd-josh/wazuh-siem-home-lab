#!/usr/bin/env python3
"""
SendMonster – Interactive colourful SMTP campaign tool for Linux
"""

from __future__ import annotations

import json
import os
import random
import re
import smtplib
import ssl
import sys
import time
from datetime import datetime
from email.mime.application import MIMEApplication
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr, make_msgid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Third-party
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
    from rich.prompt import Prompt, Confirm, IntPrompt
    from rich.text import Text
    from rich.markdown import Markdown
    from rich.align import Align
    from rich import box
    from rich.rule import Rule
except ImportError:
    print("Missing 'rich'. Install with: pip install rich")
    sys.exit(1)

try:
    import phonenumbers
    from phonenumbers import carrier as pn_carrier, NumberParseException
except ImportError:
    phonenumbers = None  # type: ignore

try:
    import qrcode
    from qrcode.constants import ERROR_CORRECT_H
except ImportError:
    qrcode = None  # type: ignore

# ---------------------------------------------------------------------------
# Paths & constants
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
TEMPLATES_DIR = BASE_DIR / "templates"
ATTACHMENTS_DIR = BASE_DIR / "attachments"
QR_DIR = BASE_DIR / "qr_codes"

for d in (DATA_DIR, TEMPLATES_DIR, ATTACHMENTS_DIR, QR_DIR):
    d.mkdir(parents=True, exist_ok=True)

SMTPS_FILE = DATA_DIR / "smtps.json"
EMAIL_LEADS_FILE = DATA_DIR / "email_leads.json"
PHONE_LEADS_FILE = DATA_DIR / "phone_leads.json"
CAMPAIGNS_FILE = DATA_DIR / "campaigns.json"
SETTINGS_FILE = DATA_DIR / "settings.json"
SEND_LOG = DATA_DIR / "send_log.txt"

console = Console()

# ---------------------------------------------------------------------------
# Known email-to-SMS gateways (status as of mid/late 2026)
# Many major ones are DEAD or dying. Tool will warn the user.
# ---------------------------------------------------------------------------
SMTP2SMS_GATEWAYS: Dict[str, Dict[str, str]] = {
    # US
    "verizon": {
        "name": "Verizon Wireless",
        "sms": "vtext.com",
        "mms": "vzwpix.com",
        "status": "DEGRADED – full shutdown scheduled ~March 2027, heavily filtered",
    },
    "google_fi": {
        "name": "Google Fi",
        "sms": "msg.fi.google.com",
        "mms": "msg.fi.google.com",
        "status": "WORKING (most reliable remaining free gateway, Fi numbers only)",
    },
    "us_cellular": {
        "name": "US Cellular",
        "sms": "email.uscc.net",
        "mms": "mms.uscc.net",
        "status": "UNCERTAIN – reported working, future unclear after T-Mobile acquisition",
    },
    "boost": {
        "name": "Boost Mobile",
        "sms": "sms.myboostmobile.com",
        "mms": "myboostmobile.com",
        "status": "MOSTLY DEAD / unreliable",
    },
    "metro": {
        "name": "Metro by T-Mobile",
        "sms": "mymetropcs.com",
        "mms": "mymetropcs.com",
        "status": "DEAD (parent T-Mobile gateway gone)",
    },
    "tmobile": {
        "name": "T-Mobile",
        "sms": "tmomail.net",
        "mms": "tmomail.net",
        "status": "DEAD – stopped ~Dec 2024",
    },
    "att": {
        "name": "AT&T",
        "sms": "txt.att.net",
        "mms": "mms.att.net",
        "status": "DEAD – permanently shut down June 2025",
    },
    "cricket": {
        "name": "Cricket Wireless",
        "sms": "sms.cricketwireless.net",
        "mms": "mms.cricketwireless.net",
        "status": "DEAD (with AT&T)",
    },
    "consumer_cellular": {
        "name": "Consumer Cellular",
        "sms": "mailmymobile.net",
        "mms": "mailmymobile.net",
        "status": "UNCERTAIN",
    },
    "c_spire": {
        "name": "C-Spire",
        "sms": "cspire1.com",
        "mms": "",
        "status": "REPORTED WORKING (regional)",
    },
    "visible": {
        "name": "Visible (Verizon MVNO)",
        "sms": "vtext.com",
        "mms": "vzwpix.com",
        "status": "DEGRADED (uses Verizon)",
    },
    # Canada
    "bell": {
        "name": "Bell Mobility (Canada)",
        "sms": "txt.bell.ca",
        "mms": "txt.bell.ca",
        "status": "ENDING / ended ~Dec 2025",
    },
    "telus": {
        "name": "Telus (Canada)",
        "sms": "msg.telus.com",
        "mms": "msg.telus.com",
        "status": "UNCERTAIN",
    },
    "rogers": {
        "name": "Rogers (Canada)",
        "sms": "pcs.rogers.com",
        "mms": "pcs.rogers.com",
        "status": "REPORTED DISCONTINUED",
    },
    "fido": {
        "name": "Fido (Canada)",
        "sms": "fido.ca",
        "mms": "fido.ca",
        "status": "UNCERTAIN",
    },
    "koodo": {
        "name": "Koodo (Canada)",
        "sms": "msg.koodomobile.com",
        "mms": "msg.koodomobile.com",
        "status": "UNCERTAIN",
    },
    "virgin_ca": {
        "name": "Virgin Mobile Canada",
        "sms": "vmobile.ca",
        "mms": "vmobile.ca",
        "status": "UNCERTAIN",
    },
}

# Simple keyword → gateway key matching for phonenumbers carrier names
CARRIER_KEYWORDS: Dict[str, str] = {
    "verizon": "verizon",
    "vzw": "verizon",
    "google": "google_fi",
    "fi": "google_fi",
    "us cellular": "us_cellular",
    "united states cellular": "us_cellular",
    "boost": "boost",
    "metro": "metro",
    "metropcs": "metro",
    "t-mobile": "tmobile",
    "tmobile": "tmobile",
    "at&t": "att",
    "att": "att",
    "cingular": "att",
    "cricket": "cricket",
    "consumer cellular": "consumer_cellular",
    "c-spire": "c_spire",
    "cspire": "c_spire",
    "visible": "visible",
    "bell": "bell",
    "telus": "telus",
    "rogers": "rogers",
    "fido": "fido",
    "koodo": "koodo",
    "virgin": "virgin_ca",
}

# ---------------------------------------------------------------------------
# Helpers: JSON persistence
# ---------------------------------------------------------------------------
def load_json(path: Path, default: Any) -> Any:
    if path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return default
    return default


def save_json(path: Path, data: Any) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def get_settings() -> Dict[str, Any]:
    defaults = {
        "rotation": "round_robin",  # or "random"
        "delay_seconds": 2.0,
        "default_from_name": "SendMonster",
        "max_per_smtp_per_run": 50,
    }
    s = load_json(SETTINGS_FILE, {})
    defaults.update(s)
    return defaults


def save_settings(s: Dict[str, Any]) -> None:
    save_json(SETTINGS_FILE, s)


# ---------------------------------------------------------------------------
# Banner & UI helpers
# ---------------------------------------------------------------------------
BANNER = r"""
[bold red]
   ███████╗███████╗███╗   ██╗██████╗ ███╗   ███╗ ██████╗ ███╗   ██╗███████╗████████╗███████╗██████╗ 
   ██╔════╝██╔════╝████╗  ██║██╔══██╗████╗ ████║██╔═══██╗████╗  ██║██╔════╝╚══██╔══╝██╔════╝██╔══██╗
   ███████╗█████╗  ██╔██╗ ██║██║  ██║██╔████╔██║██║   ██║██╔██╗ ██║███████╗   ██║   █████╗  ██████╔╝
   ╚════██║██╔══╝  ██║╚██╗██║██║  ██║██║╚██╔╝██║██║   ██║██║╚██╗██║╚════██║   ██║   ██╔══╝  ██╔══██╗
   ███████║███████╗██║ ╚████║██████╔╝██║ ╚═╝ ██║╚██████╔╝██║ ╚████║███████║   ██║   ███████╗██║  ██║
   ╚══════╝╚══════╝╚═╝  ╚═══╝╚═════╝ ╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚══════╝╚═╝  ╚═╝
[/bold red]
[bold yellow]          ⚡ Interactive SMTP Campaign Monster for Linux ⚡[/bold yellow]
[dim]                    Multiple SMTPs • Rotation • HTML + QR • SMTP2SMS[/dim]
"""


def clear() -> None:
    console.clear()


def header(title: str) -> None:
    console.print(Rule(f"[bold cyan]{title}[/bold cyan]", style="cyan"))


def success(msg: str) -> None:
    console.print(f"[bold green]✔ {msg}[/bold green]")


def error(msg: str) -> None:
    console.print(f"[bold red]✘ {msg}[/bold red]")


def warn(msg: str) -> None:
    console.print(f"[bold yellow]⚠ {msg}[/bold yellow]")


def info(msg: str) -> None:
    console.print(f"[bold blue]ℹ {msg}[/bold blue]")


def pause() -> None:
    console.print()
    Prompt.ask("[dim]Press Enter to continue[/dim]", default="")


# ---------------------------------------------------------------------------
# SMTP Pool
# ---------------------------------------------------------------------------
def load_smtps() -> List[Dict[str, Any]]:
    return load_json(SMTPS_FILE, [])


def save_smtps(smtps: List[Dict[str, Any]]) -> None:
    save_json(SMTPS_FILE, smtps)


def add_smtp() -> None:
    header("Add SMTP Configuration")
    name = Prompt.ask("Friendly name (e.g. Gmail-1)")
    host = Prompt.ask("SMTP host", default="smtp.gmail.com")
    port = IntPrompt.ask("Port", default=587)
    use_tls = Confirm.ask("Use STARTTLS?", default=True)
    use_ssl = Confirm.ask("Use SSL (port 465 style)?", default=False)
    username = Prompt.ask("Username / email")
    password = Prompt.ask("Password / app password", password=True)
    from_email = Prompt.ask("From email address", default=username)
    from_name = Prompt.ask("From display name", default=get_settings()["default_from_name"])
    daily_limit = IntPrompt.ask("Soft daily limit (0 = unlimited)", default=200)

    entry = {
        "id": f"smtp_{int(time.time())}_{random.randint(100,999)}",
        "name": name,
        "host": host,
        "port": port,
        "use_tls": use_tls,
        "use_ssl": use_ssl,
        "username": username,
        "password": password,
        "from_email": from_email,
        "from_name": from_name,
        "daily_limit": daily_limit,
        "sent_today": 0,
        "last_reset": datetime.now().strftime("%Y-%m-%d"),
        "enabled": True,
        "last_error": "",
    }
    smtps = load_smtps()
    smtps.append(entry)
    save_smtps(smtps)
    success(f"Added SMTP '{name}'")
    pause()


def list_smtps() -> None:
    header("SMTP Pool")
    smtps = load_smtps()
    if not smtps:
        warn("No SMTP accounts configured yet.")
        pause()
        return
    table = Table(title="SMTP Configurations", box=box.ROUNDED, show_lines=True)
    table.add_column("#", style="dim", width=3)
    table.add_column("Name", style="cyan")
    table.add_column("Host:Port")
    table.add_column("From")
    table.add_column("Limit", justify="right")
    table.add_column("Sent", justify="right")
    table.add_column("Status")
    for i, s in enumerate(smtps, 1):
        status = "[green]ON[/green]" if s.get("enabled") else "[red]OFF[/red]"
        if s.get("last_error"):
            status += f" [red]({s['last_error'][:20]})[/red]"
        table.add_row(
            str(i),
            s["name"],
            f"{s['host']}:{s['port']}",
            s["from_email"],
            str(s.get("daily_limit", 0) or "∞"),
            str(s.get("sent_today", 0)),
            status,
        )
    console.print(table)
    pause()


def test_smtp(idx: Optional[int] = None) -> None:
    smtps = load_smtps()
    if not smtps:
        error("No SMTPs to test.")
        pause()
        return
    if idx is None:
        list_smtps()
        idx = IntPrompt.ask("Number of SMTP to test", default=1) - 1
    if not (0 <= idx < len(smtps)):
        error("Invalid index")
        pause()
        return
    s = smtps[idx]
    header(f"Testing {s['name']}")
    try:
        if s.get("use_ssl"):
            context = ssl.create_default_context()
            server = smtplib.SMTP_SSL(s["host"], s["port"], context=context, timeout=20)
        else:
            server = smtplib.SMTP(s["host"], s["port"], timeout=20)
            if s.get("use_tls"):
                server.starttls(context=ssl.create_default_context())
        server.login(s["username"], s["password"])
        server.quit()
        success(f"Login OK for {s['name']}")
        s["last_error"] = ""
    except Exception as e:
        error(f"Failed: {e}")
        s["last_error"] = str(e)[:80]
    save_smtps(smtps)
    pause()


def remove_smtp() -> None:
    smtps = load_smtps()
    if not smtps:
        error("Nothing to remove.")
        pause()
        return
    list_smtps()
    idx = IntPrompt.ask("Number to remove (0 = cancel)", default=0) - 1
    if idx < 0:
        return
    if 0 <= idx < len(smtps):
        name = smtps[idx]["name"]
        if Confirm.ask(f"Delete '{name}'?"):
            smtps.pop(idx)
            save_smtps(smtps)
            success("Removed.")
    pause()


def smtp_menu() -> None:
    while True:
        clear()
        header("SMTP Pool Manager")
        console.print("""
[bold cyan]1.[/] Add SMTP
[bold cyan]2.[/] List SMTPs
[bold cyan]3.[/] Test SMTP
[bold cyan]4.[/] Remove SMTP
[bold cyan]5.[/] Toggle enable/disable
[bold cyan]0.[/] Back
""")
        choice = Prompt.ask("Choice", choices=["0", "1", "2", "3", "4", "5"], default="0")
        if choice == "0":
            break
        elif choice == "1":
            add_smtp()
        elif choice == "2":
            list_smtps()
        elif choice == "3":
            test_smtp()
        elif choice == "4":
            remove_smtp()
        elif choice == "5":
            smtps = load_smtps()
            if not smtps:
                error("Empty pool")
                pause()
                continue
            list_smtps()
            idx = IntPrompt.ask("Number to toggle") - 1
            if 0 <= idx < len(smtps):
                smtps[idx]["enabled"] = not smtps[idx].get("enabled", True)
                save_smtps(smtps)
                success(f"Now {'enabled' if smtps[idx]['enabled'] else 'disabled'}")
            pause()


# ---------------------------------------------------------------------------
# Leads
# ---------------------------------------------------------------------------
def load_email_leads() -> List[Dict[str, str]]:
    return load_json(EMAIL_LEADS_FILE, [])


def save_email_leads(leads: List[Dict[str, str]]) -> None:
    save_json(EMAIL_LEADS_FILE, leads)


def load_phone_leads() -> List[Dict[str, str]]:
    return load_json(PHONE_LEADS_FILE, [])


def save_phone_leads(leads: List[Dict[str, str]]) -> None:
    save_json(PHONE_LEADS_FILE, leads)


def import_email_leads() -> None:
    header("Import Email Leads")
    path = Prompt.ask("Path to .txt or .csv (one email per line, optional name,email)")
    p = Path(path).expanduser()
    if not p.exists():
        error("File not found")
        pause()
        return
    leads = load_email_leads()
    existing = {l["email"].lower() for l in leads}
    added = 0
    with open(p, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "," in line:
                parts = [x.strip() for x in line.split(",", 1)]
                name, email = (parts[0], parts[1]) if "@" in parts[1] else (parts[1], parts[0])
            else:
                name, email = "", line
            email = email.lower().strip()
            if "@" not in email or email in existing:
                continue
            leads.append({"email": email, "name": name, "added": datetime.now().isoformat()})
            existing.add(email)
            added += 1
    save_email_leads(leads)
    success(f"Added {added} new email leads (total {len(leads)})")
    pause()


def import_phone_leads() -> None:
    header("Import Phone Leads")
    path = Prompt.ask("Path to .txt (one number per line, any format)")
    p = Path(path).expanduser()
    if not p.exists():
        error("File not found")
        pause()
        return
    leads = load_phone_leads()
    existing = {re.sub(r"\D", "", l["raw"]) for l in leads}
    added = 0
    with open(p, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            raw = line.strip()
            if not raw or raw.startswith("#"):
                continue
            digits = re.sub(r"\D", "", raw)
            if len(digits) < 10 or digits in existing:
                continue
            leads.append({"raw": raw, "digits": digits, "added": datetime.now().isoformat()})
            existing.add(digits)
            added += 1
    save_phone_leads(leads)
    success(f"Added {added} phone leads (total {len(leads)})")
    pause()


def list_leads(kind: str = "email") -> None:
    if kind == "email":
        leads = load_email_leads()
        title = "Email Leads"
        cols = ["email", "name"]
    else:
        leads = load_phone_leads()
        title = "Phone Leads"
        cols = ["raw", "digits"]
    header(title)
    if not leads:
        warn("Empty list")
        pause()
        return
    table = Table(title=f"{title} ({len(leads)})", box=box.SIMPLE)
    table.add_column("#", width=4)
    for c in cols:
        table.add_column(c.capitalize())
    for i, l in enumerate(leads[:50], 1):
        table.add_row(str(i), *[str(l.get(c, "")) for c in cols])
    if len(leads) > 50:
        table.add_row("…", f"(+{len(leads)-50} more)", "")
    console.print(table)
    pause()


def leads_menu() -> None:
    while True:
        clear()
        header("Lead Manager")
        console.print("""
[bold cyan]1.[/] Import email leads (txt/csv)
[bold cyan]2.[/] List email leads
[bold cyan]3.[/] Clear email leads
[bold cyan]4.[/] Import phone leads
[bold cyan]5.[/] List phone leads
[bold cyan]6.[/] Clear phone leads
[bold cyan]0.[/] Back
""")
        choice = Prompt.ask("Choice", choices=["0", "1", "2", "3", "4", "5", "6"], default="0")
        if choice == "0":
            break
        elif choice == "1":
            import_email_leads()
        elif choice == "2":
            list_leads("email")
        elif choice == "3":
            if Confirm.ask("Really clear all email leads?"):
                save_email_leads([])
                success("Cleared")
            pause()
        elif choice == "4":
            import_phone_leads()
        elif choice == "5":
            list_leads("phone")
        elif choice == "6":
            if Confirm.ask("Really clear all phone leads?"):
                save_phone_leads([])
                success("Cleared")
            pause()


# ---------------------------------------------------------------------------
# SMTP2SMS
# ---------------------------------------------------------------------------
def normalize_us_ca_number(digits: str) -> Optional[str]:
    """Return 10-digit national number if possible."""
    d = re.sub(r"\D", "", digits)
    if len(d) == 11 and d.startswith("1"):
        return d[1:]
    if len(d) == 10:
        return d
    return None


def guess_carrier_key(phone_digits: str) -> Tuple[Optional[str], str]:
    """Return (gateway_key, human_carrier_name) using phonenumbers if available."""
    if not phonenumbers:
        return None, "unknown (install phonenumbers)"
    try:
        # Prefer +1 for NA
        num = phonenumbers.parse("+" + phone_digits if not phone_digits.startswith("+") else phone_digits, None)
        if not phonenumbers.is_possible_number(num):
            return None, "invalid"
        name = pn_carrier.name_for_number(num, "en") or ""
        name_l = name.lower()
        for kw, key in CARRIER_KEYWORDS.items():
            if kw in name_l:
                return key, name or key
        return None, name or "unknown"
    except NumberParseException:
        return None, "parse error"
    except Exception:
        return None, "lookup error"


def smtp2sms_convert() -> None:
    clear()
    header("SMTP2SMS Converter")
    console.print(Panel(
        "[bold yellow]WARNING[/bold yellow]\n"
        "Most major free carrier email-to-SMS gateways (AT&T, T-Mobile, …) are "
        "[bold red]DEAD or dying[/bold red] as of 2026.\n"
        "Verizon is heavily filtered and scheduled for full shutdown ~March 2027.\n"
        "Google Fi remains one of the few relatively reliable free holdouts.\n\n"
        "For serious volume use a registered A2P / 10DLC SMS provider instead.",
        title="Gateway Reality Check",
        border_style="yellow",
    ))
    console.print()
    console.print("""
[bold cyan]1.[/] Convert from imported phone leads
[bold cyan]2.[/] Convert a single number / paste list
[bold cyan]3.[/] Show known gateways & status
[bold cyan]0.[/] Back
""")
    choice = Prompt.ask("Choice", choices=["0", "1", "2", "3"], default="0")
    if choice == "0":
        return
    if choice == "3":
        table = Table(title="Known Email↔SMS Gateways (2026 status)", box=box.ROUNDED)
        table.add_column("Key", style="cyan")
        table.add_column("Carrier")
        table.add_column("SMS domain")
        table.add_column("Status")
        for k, g in SMTP2SMS_GATEWAYS.items():
            style = "green" if "WORKING" in g["status"] else ("yellow" if "UNCERTAIN" in g["status"] or "DEGRADED" in g["status"] else "red")
            table.add_row(k, g["name"], g["sms"], f"[{style}]{g['status']}[/{style}]")
        console.print(table)
        pause()
        return

    numbers: List[str] = []
    if choice == "1":
        phones = load_phone_leads()
        if not phones:
            error("No phone leads imported yet.")
            pause()
            return
        numbers = [p["digits"] for p in phones]
        info(f"Loaded {len(numbers)} numbers from phone leads")
    else:
        raw = Prompt.ask("Paste numbers (comma / space / newline separated)")
        numbers = re.findall(r"[\d\+\-\(\)\s]{8,}", raw)
        numbers = [re.sub(r"\D", "", n) for n in numbers if re.sub(r"\D", "", n)]

    if not numbers:
        error("No numbers found")
        pause()
        return

    # Carrier selection mode
    mode = Prompt.ask(
        "Carrier mode",
        choices=["auto", "manual", "force"],
        default="auto",
        show_choices=True,
    )
    force_key = None
    if mode == "force":
        console.print("Available keys: " + ", ".join(SMTP2SMS_GATEWAYS.keys()))
        force_key = Prompt.ask("Force gateway key")
        if force_key not in SMTP2SMS_GATEWAYS:
            error("Unknown key")
            pause()
            return

    results = []
    supported = []
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Processing…", total=len(numbers))
        for digits in numbers:
            nat = normalize_us_ca_number(digits)
            if not nat:
                results.append({"digits": digits, "status": "skip (not 10-digit NA)", "email": ""})
                progress.advance(task)
                continue

            if force_key:
                key = force_key
                cname = SMTP2SMS_GATEWAYS[key]["name"]
            else:
                key, cname = guess_carrier_key("1" + nat)
                if mode == "manual" or key is None:
                    # Interactive fallback for this number
                    console.print(f"\nNumber [cyan]{nat}[/] – detected: [yellow]{cname}[/]")
                    console.print("Keys: " + ", ".join(SMTP2SMS_GATEWAYS.keys()) + " | skip")
                    key = Prompt.ask("Gateway key (or skip)", default="skip")
                    if key == "skip" or key not in SMTP2SMS_GATEWAYS:
                        results.append({"digits": nat, "status": "skipped by user", "email": ""})
                        progress.advance(task)
                        continue
                    cname = SMTP2SMS_GATEWAYS[key]["name"]

            gw = SMTP2SMS_GATEWAYS[key]
            email_addr = f"{nat}@{gw['sms']}"
            status = gw["status"]
            results.append({
                "digits": nat,
                "carrier": cname,
                "gateway": key,
                "email": email_addr,
                "status": status,
            })
            if "DEAD" not in status.upper():
                supported.append(email_addr)
            progress.advance(task)

    # Summary
    header("Conversion Results")
    table = Table(box=box.SIMPLE_HEAVY)
    table.add_column("Number")
    table.add_column("Carrier")
    table.add_column("Email gateway")
    table.add_column("Status note")
    for r in results[:30]:
        style = "green" if r.get("email") and "DEAD" not in r.get("status", "").upper() else "red"
        table.add_row(
            r.get("digits", ""),
            r.get("carrier", r.get("status", "")),
            f"[{style}]{r.get('email', '-')}[/{style}]",
            r.get("status", "")[:50],
        )
    console.print(table)
    if len(results) > 30:
        info(f"… and {len(results)-30} more")

    console.print()
    info(f"Potentially usable (non-DEAD) addresses: {len(supported)}")
    if supported and Confirm.ask("Export these as email leads / save to file?"):
        # Add to email leads
        emails = load_email_leads()
        existing = {e["email"].lower() for e in emails}
        added = 0
        for addr in supported:
            if addr.lower() not in existing:
                emails.append({"email": addr, "name": "sms2email", "added": datetime.now().isoformat()})
                existing.add(addr.lower())
                added += 1
        save_email_leads(emails)
        # Also write a plain list
        out = DATA_DIR / f"smtp2sms_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        with open(out, "w") as f:
            f.write("\n".join(supported))
        success(f"Added {added} to email leads and saved list → {out}")
    pause()


# ---------------------------------------------------------------------------
# Campaign / HTML editor + QR + attachments
# ---------------------------------------------------------------------------
def load_campaigns() -> Dict[str, Any]:
    return load_json(CAMPAIGNS_FILE, {})


def save_campaigns(data: Dict[str, Any]) -> None:
    save_json(CAMPAIGNS_FILE, data)


def create_template() -> None:
    header("Create HTML Campaign Template")
    name = Prompt.ask("Template name (no spaces)", default=f"campaign_{int(time.time())}")
    subject = Prompt.ask("Email subject line", default="Hello {{name}}!")
    console.print(
        "[dim]You can use placeholders: {{name}} {{email}} {{date}}\n"
        "Paste HTML below. End with a line containing only ###END###[/dim]"
    )
    lines = []
    while True:
        try:
            line = input()
        except EOFError:
            break
        if line.strip() == "###END###":
            break
        lines.append(line)
    html = "\n".join(lines) or "<html><body><h1>Hello {{name}}</h1><p>Your content here.</p></body></html>"

    # Optional QR
    qr_path = None
    if qrcode and Confirm.ask("Generate a QR code and embed it?", default=False):
        data = Prompt.ask("QR content (URL or text)")
        img = qrcode.make(data, error_correction=ERROR_CORRECT_H, box_size=6, border=2)
        qr_path = QR_DIR / f"{name}_qr.png"
        img.save(qr_path)
        # Simple base64 embed note – user can also attach
        success(f"QR saved to {qr_path}")
        html += f'\n<!-- QR image available at: {qr_path} – attach or base64 embed -->\n'

    # Attachments
    atts = []
    while Confirm.ask("Add an attachment file?", default=False):
        p = Path(Prompt.ask("File path")).expanduser()
        if p.exists() and p.is_file():
            dest = ATTACHMENTS_DIR / p.name
            import shutil
            shutil.copy2(p, dest)
            atts.append(str(dest))
            success(f"Copied → {dest}")
        else:
            error("Not found")

    campaigns = load_campaigns()
    campaigns[name] = {
        "subject": subject,
        "html": html,
        "qr": str(qr_path) if qr_path else None,
        "attachments": atts,
        "created": datetime.now().isoformat(),
    }
    # Also write a .html file for external editing
    tpl_file = TEMPLATES_DIR / f"{name}.html"
    with open(tpl_file, "w", encoding="utf-8") as f:
        f.write(html)
    save_campaigns(campaigns)
    success(f"Template '{name}' saved. HTML also at {tpl_file}")
    info("Tip: edit the .html file in your favourite editor then re-import if needed.")
    pause()


def list_templates() -> None:
    header("Campaign Templates")
    camps = load_campaigns()
    if not camps:
        warn("No templates yet")
        pause()
        return
    table = Table(box=box.ROUNDED)
    table.add_column("Name", style="cyan")
    table.add_column("Subject")
    table.add_column("QR")
    table.add_column("Attachments", justify="right")
    for name, c in camps.items():
        table.add_row(
            name,
            c.get("subject", "")[:40],
            "yes" if c.get("qr") else "no",
            str(len(c.get("attachments", []))),
        )
    console.print(table)
    pause()


def edit_template_external() -> None:
    camps = load_campaigns()
    if not camps:
        error("No templates")
        pause()
        return
    list_templates()
    name = Prompt.ask("Template name to edit in external editor")
    if name not in camps:
        error("Unknown")
        pause()
        return
    tpl = TEMPLATES_DIR / f"{name}.html"
    editor = os.environ.get("EDITOR", "nano")
    console.print(f"Opening with [cyan]{editor}[/] …")
    os.system(f'{editor} "{tpl}"')
    # Reload
    if tpl.exists():
        with open(tpl, encoding="utf-8") as f:
            camps[name]["html"] = f.read()
        save_campaigns(camps)
        success("Reloaded HTML from file")
    pause()


def campaign_menu() -> None:
    while True:
        clear()
        header("Campaign Editor")
        console.print("""
[bold cyan]1.[/] Create new HTML template (paste + optional QR + attachments)
[bold cyan]2.[/] List templates
[bold cyan]3.[/] Edit template HTML in $EDITOR (nano/vim/…)
[bold cyan]4.[/] Generate standalone QR code
[bold cyan]0.[/] Back
""")
        choice = Prompt.ask("Choice", choices=["0", "1", "2", "3", "4"], default="0")
        if choice == "0":
            break
        elif choice == "1":
            create_template()
        elif choice == "2":
            list_templates()
        elif choice == "3":
            edit_template_external()
        elif choice == "4":
            if not qrcode:
                error("qrcode library missing")
                pause()
                continue
            data = Prompt.ask("QR content")
            fname = Prompt.ask("Output filename (no ext)", default=f"qr_{int(time.time())}")
            img = qrcode.make(data, error_correction=ERROR_CORRECT_H)
            path = QR_DIR / f"{fname}.png"
            img.save(path)
            success(f"Saved → {path}")
            pause()


# ---------------------------------------------------------------------------
# Sending engine with rotation
# ---------------------------------------------------------------------------
def render_template(html: str, subject: str, lead: Dict[str, str]) -> Tuple[str, str]:
    mapping = {
        "{{name}}": lead.get("name") or lead.get("email", "").split("@")[0],
        "{{email}}": lead.get("email", ""),
        "{{date}}": datetime.now().strftime("%Y-%m-%d"),
    }
    for k, v in mapping.items():
        html = html.replace(k, v)
        subject = subject.replace(k, v)
    return subject, html


def get_next_smtp(smtps: List[Dict], idx: int, settings: Dict) -> Tuple[Optional[Dict], int]:
    enabled = [s for s in smtps if s.get("enabled", True)]
    if not enabled:
        return None, idx
    today = datetime.now().strftime("%Y-%m-%d")
    for s in enabled:
        if s.get("last_reset") != today:
            s["sent_today"] = 0
            s["last_reset"] = today
    usable = [
        s for s in enabled
        if s.get("daily_limit", 0) == 0 or s.get("sent_today", 0) < s["daily_limit"]
    ]
    if not usable:
        return None, idx
    mode = settings.get("rotation", "round_robin")
    if mode == "random":
        return random.choice(usable), idx
    # round_robin
    s = usable[idx % len(usable)]
    return s, idx + 1


def build_message(
    smtp: Dict,
    to_email: str,
    subject: str,
    html: str,
    attachments: List[str],
    qr_path: Optional[str] = None,
) -> MIMEMultipart:
    msg = MIMEMultipart("related")
    msg["Subject"] = subject
    msg["From"] = formataddr((smtp.get("from_name", ""), smtp["from_email"]))
    msg["To"] = to_email
    msg["Message-ID"] = make_msgid()

    alt = MIMEMultipart("alternative")
    alt.attach(MIMEText("Please view this email in an HTML-capable client.", "plain"))
    alt.attach(MIMEText(html, "html"))
    msg.attach(alt)

    # Optional inline QR
    if qr_path and Path(qr_path).exists():
        with open(qr_path, "rb") as f:
            img = MIMEImage(f.read())
        img.add_header("Content-ID", "<qrcode>")
        img.add_header("Content-Disposition", "inline", filename="qrcode.png")
        msg.attach(img)

    for att_path in attachments:
        p = Path(att_path)
        if not p.exists():
            continue
        with open(p, "rb") as f:
            part = MIMEApplication(f.read(), Name=p.name)
        part["Content-Disposition"] = f'attachment; filename="{p.name}"'
        msg.attach(part)
    return msg


def send_one(smtp: Dict, msg: MIMEMultipart) -> None:
    if smtp.get("use_ssl"):
        context = ssl.create_default_context()
        server = smtplib.SMTP_SSL(smtp["host"], smtp["port"], context=context, timeout=30)
    else:
        server = smtplib.SMTP(smtp["host"], smtp["port"], timeout=30)
        if smtp.get("use_tls"):
            server.starttls(context=ssl.create_default_context())
    server.login(smtp["username"], smtp["password"])
    server.send_message(msg)
    server.quit()


def send_campaign() -> None:
    clear()
    header("Send Campaign")
    smtps = load_smtps()
    if not any(s.get("enabled") for s in smtps):
        error("No enabled SMTPs in the pool. Add & enable some first.")
        pause()
        return
    camps = load_campaigns()
    if not camps:
        error("No campaign templates. Create one first.")
        pause()
        return
    emails = load_email_leads()
    if not emails:
        error("No email leads. Import some (or run SMTP2SMS).")
        pause()
        return

    console.print("Templates: " + ", ".join(camps.keys()))
    tname = Prompt.ask("Template name")
    if tname not in camps:
        error("Unknown template")
        pause()
        return
    camp = camps[tname]

    settings = get_settings()
    max_send = IntPrompt.ask(
        "Max emails this run (0 = all)",
        default=min(len(emails), settings.get("max_per_smtp_per_run", 50) * max(1, len(smtps))),
    )
    if max_send <= 0:
        max_send = len(emails)
    delay = float(Prompt.ask("Delay between sends (seconds)", default=str(settings.get("delay_seconds", 2.0))))
    dry = Confirm.ask("Dry-run (no actual send)?", default=True)

    targets = emails[:max_send]
    console.print(Panel(
        f"Template: [cyan]{tname}[/]\n"
        f"Recipients: [cyan]{len(targets)}[/]\n"
        f"SMTPs enabled: [cyan]{sum(1 for s in smtps if s.get('enabled'))}[/]\n"
        f"Rotation: [cyan]{settings.get('rotation')}[/]\n"
        f"Dry-run: [yellow]{dry}[/]",
        title="Ready to send",
    ))
    if not Confirm.ask("Proceed?"):
        return

    rr_idx = 0
    ok = fail = 0
    log_lines = []

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Sending…", total=len(targets))
        for lead in targets:
            smtp, rr_idx = get_next_smtp(smtps, rr_idx, settings)
            if not smtp:
                error("No usable SMTP left (limits reached?)")
                break
            subject, html = render_template(camp["html"], camp["subject"], lead)

            try:
                if dry:
                    log_lines.append(f"[DRY] {lead['email']} via {smtp['name']}")
                    ok += 1
                else:
                    msg = build_message(
                        smtp,
                        lead["email"],
                        subject,
                        html,
                        camp.get("attachments", []),
                        camp.get("qr"),
                    )
                    send_one(smtp, msg)
                    smtp["sent_today"] = smtp.get("sent_today", 0) + 1
                    log_lines.append(f"OK {lead['email']} via {smtp['name']}")
                    ok += 1
            except Exception as e:
                fail += 1
                smtp["last_error"] = str(e)[:80]
                log_lines.append(f"FAIL {lead['email']} via {smtp['name']}: {e}")
                error(f"{lead['email']}: {e}")
            progress.advance(task)
            if delay > 0 and not dry:
                time.sleep(delay)

    save_smtps(smtps)
    with open(SEND_LOG, "a", encoding="utf-8") as f:
        f.write(f"\n=== {datetime.now().isoformat()} ===\n")
        f.write("\n".join(log_lines) + "\n")
    console.print()
    success(f"Done. OK={ok}  FAIL={fail}")
    info(f"Log appended to {SEND_LOG}")
    pause()


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------
def settings_menu() -> None:
    s = get_settings()
    while True:
        clear()
        header("Settings")
        console.print(f"""
Rotation mode     : [cyan]{s.get('rotation')}[/]
Delay between send: [cyan]{s.get('delay_seconds')}[/] s
Default from name : [cyan]{s.get('default_from_name')}[/]
Max per SMTP/run  : [cyan]{s.get('max_per_smtp_per_run')}[/]
""")
        console.print("""
[bold cyan]1.[/] Toggle rotation (round_robin ↔ random)
[bold cyan]2.[/] Set delay seconds
[bold cyan]3.[/] Set default from name
[bold cyan]4.[/] Set max per SMTP per run
[bold cyan]0.[/] Back
""")
        c = Prompt.ask("Choice", choices=["0", "1", "2", "3", "4"], default="0")
        if c == "0":
            break
        elif c == "1":
            s["rotation"] = "random" if s.get("rotation") == "round_robin" else "round_robin"
            success(f"Now: {s['rotation']}")
        elif c == "2":
            s["delay_seconds"] = float(Prompt.ask("Seconds", default=str(s["delay_seconds"])))
        elif c == "3":
            s["default_from_name"] = Prompt.ask("Name", default=s["default_from_name"])
        elif c == "4":
            s["max_per_smtp_per_run"] = IntPrompt.ask("Max", default=s["max_per_smtp_per_run"])
        save_settings(s)
        pause()


# ---------------------------------------------------------------------------
# Main menu
# ---------------------------------------------------------------------------
def main_menu() -> None:
    while True:
        clear()
        console.print(Align.center(BANNER))
        console.print(Rule(style="red"))
        console.print("""
[bold white]  1.[/] [bold cyan]SMTP Pool Manager[/]     – add / test / rotate accounts
[bold white]  2.[/] [bold cyan]Lead Manager[/]          – email & phone lists
[bold white]  3.[/] [bold magenta]SMTP2SMS Converter[/]    – phones → carrier gateways → emails
[bold white]  4.[/] [bold yellow]Campaign Editor[/]       – HTML + QR + attachments
[bold white]  5.[/] [bold green]Send Campaign[/]         – fire with pool rotation
[bold white]  6.[/] [bold blue]Settings[/]
[bold white]  0.[/] [bold red]Exit[/]
""")
        choice = Prompt.ask(
            "[bold]Select[/]",
            choices=["0", "1", "2", "3", "4", "5", "6"],
            default="0",
        )
        if choice == "0":
            console.print("\n[bold red]SendMonster signing off. Stay legal.[/bold red]\n")
            break
        elif choice == "1":
            smtp_menu()
        elif choice == "2":
            leads_menu()
        elif choice == "3":
            smtp2sms_convert()
        elif choice == "4":
            campaign_menu()
        elif choice == "5":
            send_campaign()
        elif choice == "6":
            settings_menu()


if __name__ == "__main__":
    try:
        main_menu()
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted.[/yellow]")
        sys.exit(0)
